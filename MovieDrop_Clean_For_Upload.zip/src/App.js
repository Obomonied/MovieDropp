import React from "react";

function App() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>🎬 Welcome to MovieDrop</h1>
      <p>Download the latest foreign and African movies.</p>
    </div>
  );
}

export default App;